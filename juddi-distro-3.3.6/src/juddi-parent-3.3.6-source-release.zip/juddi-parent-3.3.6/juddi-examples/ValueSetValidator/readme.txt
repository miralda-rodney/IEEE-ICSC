To deploy


mvn clean install

Then

Copy the jar file into juddi-tomcat/target/tomcat/apache-tomcat.../juddiv3.war/WEB-INF/lib and restart Tomcat


To test:

mvn clean install -Pdemo